--
-- PostgreSQL database dump
--

\restrict 1m0H8x7SuozH5YFog2l5gcYtAmK9fAai8MsL2DBTZMhAWxruN9nxhUfNiT7e3fK

-- Dumped from database version 16.11 (Debian 16.11-1.pgdg13+1)
-- Dumped by pg_dump version 16.11 (Debian 16.11-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: orders_status_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.orders_status_enum AS ENUM (
    'PENDING',
    'PAID'
);


ALTER TYPE public.orders_status_enum OWNER TO postgres;

--
-- Name: users_role_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.users_role_enum AS ENUM (
    'user',
    'admin'
);


ALTER TYPE public.users_role_enum OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: cart_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cart_items (
    id integer NOT NULL,
    cart_id integer NOT NULL,
    product_id integer NOT NULL,
    quantity integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.cart_items OWNER TO postgres;

--
-- Name: cart_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cart_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cart_items_id_seq OWNER TO postgres;

--
-- Name: cart_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cart_items_id_seq OWNED BY public.cart_items.id;


--
-- Name: carts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.carts (
    id integer NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.carts OWNER TO postgres;

--
-- Name: carts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.carts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.carts_id_seq OWNER TO postgres;

--
-- Name: carts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.carts_id_seq OWNED BY public.carts.id;


--
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categories (
    id integer NOT NULL,
    title character varying NOT NULL,
    description character varying NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    store_id integer NOT NULL
);


ALTER TABLE public.categories OWNER TO postgres;

--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.categories_id_seq OWNER TO postgres;

--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- Name: colors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.colors (
    id integer NOT NULL,
    name character varying NOT NULL,
    value character varying NOT NULL,
    store_id integer NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.colors OWNER TO postgres;

--
-- Name: colors_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.colors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.colors_id_seq OWNER TO postgres;

--
-- Name: colors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.colors_id_seq OWNED BY public.colors.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    "timestamp" bigint NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.migrations OWNER TO postgres;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.migrations_id_seq OWNER TO postgres;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: order_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_items (
    id integer NOT NULL,
    order_id integer NOT NULL,
    quantity integer NOT NULL,
    price integer NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    product_id integer NOT NULL,
    store_id integer NOT NULL
);


ALTER TABLE public.order_items OWNER TO postgres;

--
-- Name: order_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.order_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.order_items_id_seq OWNER TO postgres;

--
-- Name: order_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.order_items_id_seq OWNED BY public.order_items.id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    id integer NOT NULL,
    status public.orders_status_enum DEFAULT 'PENDING'::public.orders_status_enum NOT NULL,
    total integer NOT NULL,
    user_id integer NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    store_id integer NOT NULL
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.orders_id_seq OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.orders_id_seq OWNED BY public.orders.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    id integer NOT NULL,
    title character varying NOT NULL,
    description character varying NOT NULL,
    price integer DEFAULT 0,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    store_id integer NOT NULL,
    category_id integer NOT NULL,
    color_id integer NOT NULL,
    user_id integer NOT NULL,
    images text[] NOT NULL
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.products_id_seq OWNER TO postgres;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: reviews; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reviews (
    id integer NOT NULL,
    text character varying NOT NULL,
    rating integer NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    product_id integer NOT NULL,
    store_id integer NOT NULL
);


ALTER TABLE public.reviews OWNER TO postgres;

--
-- Name: reviews_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reviews_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.reviews_id_seq OWNER TO postgres;

--
-- Name: reviews_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reviews_id_seq OWNED BY public.reviews.id;


--
-- Name: stores; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stores (
    id integer NOT NULL,
    title character varying NOT NULL,
    description character varying,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    picture character varying DEFAULT '/uploads/no-store.webp'::character varying NOT NULL
);


ALTER TABLE public.stores OWNER TO postgres;

--
-- Name: stores_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.stores_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.stores_id_seq OWNER TO postgres;

--
-- Name: stores_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.stores_id_seq OWNED BY public.stores.id;


--
-- Name: user_favorite_products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_favorite_products (
    user_id integer NOT NULL,
    product_id integer NOT NULL
);


ALTER TABLE public.user_favorite_products OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    name character varying DEFAULT 'No user name'::character varying NOT NULL,
    email character varying NOT NULL,
    password character varying,
    picture character varying DEFAULT '/uploads/no-user.webp'::character varying NOT NULL,
    role public.users_role_enum DEFAULT 'user'::public.users_role_enum NOT NULL,
    cart_id integer
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: cart_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_items ALTER COLUMN id SET DEFAULT nextval('public.cart_items_id_seq'::regclass);


--
-- Name: carts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carts ALTER COLUMN id SET DEFAULT nextval('public.carts_id_seq'::regclass);


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- Name: colors id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.colors ALTER COLUMN id SET DEFAULT nextval('public.colors_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: order_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items ALTER COLUMN id SET DEFAULT nextval('public.order_items_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders ALTER COLUMN id SET DEFAULT nextval('public.orders_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: reviews id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews ALTER COLUMN id SET DEFAULT nextval('public.reviews_id_seq'::regclass);


--
-- Name: stores id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stores ALTER COLUMN id SET DEFAULT nextval('public.stores_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: cart_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cart_items (id, cart_id, product_id, quantity) FROM stdin;
6	1	3	1
7	1	25	1
8	1	26	1
\.


--
-- Data for Name: carts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.carts (id, "createdAt", "updatedAt") FROM stdin;
1	2026-02-19 20:47:36.114208	2026-02-19 20:47:36.114208
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categories (id, title, description, "createdAt", "updatedAt", store_id) FROM stdin;
2	Clothes	Phones for sell	2026-01-24 20:27:06.286946	2026-01-24 20:27:06.286946	2
6	Food		2026-01-27 20:32:48.157246	2026-01-27 20:32:48.157246	3
7	Colors	Colors description	2026-01-27 20:33:10.305032	2026-01-27 20:33:10.305032	3
5	Programming courses	A lot of courses for programming	2026-01-27 20:32:34.668637	2026-01-27 20:47:28.01782	3
8	Sport	A sport category	2026-01-29 15:37:08.454279	2026-01-29 15:37:08.454279	3
9	Tea		2026-01-29 15:39:21.684997	2026-01-29 15:39:21.684997	3
11	Flowers	Beautifull flowers	2026-01-31 13:22:51.091742	2026-01-31 13:22:51.091742	3
12	Cars	The best cars	2026-01-31 13:22:51.091742	2026-01-31 13:22:51.091742	3
13	Courses	Interesting courses	2026-01-31 13:22:51.091742	2026-01-31 13:22:51.091742	3
14	Since	Do you want to try?	2026-01-31 13:22:51.091742	2026-01-31 13:22:51.091742	3
1	Football	Footbal	2026-01-24 20:26:02.159523	2026-02-19 13:51:51.803016	2
\.


--
-- Data for Name: colors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.colors (id, name, value, store_id, "createdAt", "updatedAt") FROM stdin;
10	Blue	#48adf9	2	2026-01-24 19:43:27.709201	2026-01-24 19:43:27.709201
12	Red	#ff0000	3	2026-01-29 15:34:52.670834	2026-01-29 15:34:52.670834
13	Lima	#35D123	3	2026-01-29 15:35:29.358582	2026-01-29 15:35:29.358582
14	Java	#23BED1	3	2026-01-29 15:35:42.670761	2026-01-29 15:35:42.670761
15	Mariner	#2356D1	3	2026-01-29 15:35:58.442909	2026-01-29 15:35:58.442909
16	Cerise	#D123BB	3	2026-01-29 15:36:19.984676	2026-01-29 15:36:19.984676
17	Sunflower	#DED52B	3	2026-01-29 15:36:44.490802	2026-01-29 15:36:44.490802
11	Light green	#ccc438	2	2026-01-24 19:51:27.146829	2026-02-19 13:52:11.011989
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.migrations (id, "timestamp", name) FROM stdin;
1	1769192100711	CreateUserTable1769192100711
2	1769194377400	AddedNewColumnsToUsersTable1769194377400
3	1769195059502	CreateStore1769195059502
4	1769195118073	ChangedColumnStore1769195118073
5	1769195457326	UserStoreRelations1769195457326
6	1769195800096	CreateProductTable1769195800096
7	1769195984843	ProductStoreRelation1769195984843
8	1769196279009	ProductCategoryRelation1769196279009
9	1769196543840	CategoryStoreRelation1769196543840
10	1769196996250	ColorRelations1769196996250
11	1769197195941	Review1769197195941
12	1769197784144	ReviewProductStoreUserRelations1769197784144
13	1769198579148	OrderRelations1769198579148
14	1769198910974	FinishedOrderRelations1769198910974
15	1769341976773	ChangeColumnTypeImagesForProduct1769341976773
16	1769534930443	AddRoleColumnToUser1769534930443
17	1769701711187	ProductTableChangedPriceType1769701711187
18	1769710697656	AddPictureToStoreTable1769710697656
22	1769710849083	AddDefaultPictureToStoreTable1769710849083
23	1769867032757	ProductPriceToNumber1769867032757
24	1770146806374	OrderAddStoreId1770146806374
25	1770967070488	FavoritesProductsRelation1770967070488
26	1771533153816	CreateCartAndCartItems1771533153816
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_items (id, order_id, quantity, price, "createdAt", "updatedAt", product_id, store_id) FROM stdin;
1	1	1	489	2026-01-31 09:35:03.133447	2026-01-31 09:35:03.133447	4	3
2	1	2	748	2026-01-31 09:35:03.133447	2026-01-31 09:35:03.133447	3	3
3	1	3	1294	2026-01-31 09:35:03.133447	2026-01-31 09:35:03.133447	6	3
4	1	1	555	2026-01-31 09:35:03.133447	2026-01-31 09:35:03.133447	7	3
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (id, status, total, user_id, "createdAt", "updatedAt", store_id) FROM stdin;
1	PENDING	489	7	2026-01-31 09:26:23.843405	2026-01-31 09:26:23.843405	3
3	PENDING	555	9	2026-01-31 09:27:14.952708	2026-01-31 09:27:14.952708	3
4	PAID	732	10	2026-01-31 13:11:15.730248	2026-01-31 13:11:15.730248	3
5	PAID	1411	6	2026-01-31 13:11:51.410778	2026-01-31 13:11:51.410778	3
2	PENDING	124	7	2026-01-31 09:27:14.952708	2026-01-31 09:27:14.952708	3
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (id, title, description, price, "createdAt", "updatedAt", store_id, category_id, color_id, user_id, images) FROM stdin;
8	Reebok Nano X3 CrossFit Shoes	Versatile training shoes for lifting, running and high-intensity workouts	139	2024-12-29 15:59:51.897801	2026-01-29 19:27:08.321225	3	8	17	11	{"/uploads/products/8/1769714782814-Reebok Nano X3 CrossFit Shoes.jpg","/uploads/products/8/1769714828322-Reebok Nano X3.jpg"}
14	Pickett Solomon Traders	Duis nemo delectus, dolor perspiciatis, duis nulla explicabo. Error quisquam aliquam sit, sint reiciendis dolores in labore sequi ex maxime veritatis .	31	2024-12-29 19:54:54.573863	2026-01-29 19:55:15.266226	3	6	17	11	{"/uploads/products/14/1769716494588-Reebok Nano X3.jpg","/uploads/products/14/1769716515266-Reebok Nano X3 CrossFit Shoes.jpg"}
24	Organic Green Tea Set	Collection of 6 premium organic green tea varieties from Japan	25	2025-08-31 13:40:05.677888	2026-02-17 07:52:01.360829	3	9	17	11	{/uploads/products/24/1771314721362-organic-green-tea.jpg}
18	Organic Green Tea Set	Collection of 6 premium organic green tea varieties from Japan	25	2024-12-31 13:34:06.182858	2026-02-17 07:55:24.183814	3	11	13	11	{/uploads/products/18/1771314924183-green-tea-set.jpg}
23	Programming Course Bundle	Complete web development bootcamp with Python, JavaScript and React	199	2026-01-31 13:40:05.677888	2026-02-17 07:52:32.372648	3	5	17	11	{/uploads/products/23/1771314752373-progrmming-cours-bandle.jpg}
25	Running Shoes Trail	Waterproof trail running shoes with superior grip and cushioning	110	2026-01-31 13:40:05.677888	2026-02-17 07:52:54.884927	3	8	17	11	{/uploads/products/25/1771314774885-running-shoes.webp}
26	Red Rose Bouquet	Dozen fresh red roses with elegant wrapping and care instructions	45	2026-01-31 13:40:05.677888	2026-02-17 07:53:11.647058	3	11	17	11	{/uploads/products/26/1771314791647-red-rose.jpg}
28	Yoga Fundamentals Course	Beginner-friendly online yoga course with 30 guided video sessions	79	2026-01-31 13:40:05.677888	2026-02-17 07:53:31.545009	3	13	17	11	{/uploads/products/28/1771314811545-youga-course.jpeg}
27	Tesla Model 3 Toy Car	Die-cast metal replica with opening doors and detailed interior	36	2026-01-31 13:40:05.677888	2026-02-17 07:53:48.691392	3	12	17	11	{/uploads/products/27/1771314828691-tesla.webp}
22	Programming Course Bundle	Complete web development bootcamp with Python, JavaScript and React	199	2025-08-31 13:38:16.052936	2026-02-17 07:54:05.133026	3	5	17	11	{/uploads/products/22/1771314845133-programming-course.jpg}
21	Stainless Steel Water Bottle	Insulated 32oz water bottle keeps drinks cold for 24 hours	344	2025-08-31 13:37:12.559397	2026-02-17 07:54:24.202857	3	8	17	11	{/uploads/products/21/1771314864203-stainless-steel-botle.jpg}
20	Yoga Mat Pro	Non-slip eco-friendly yoga mat with carrying strap, 6mm thickness	36	2026-01-31 13:35:57.842391	2026-02-17 07:54:39.541003	3	8	16	11	{/uploads/products/20/1771314879541-yoga-mat.jpg}
19	Leather Laptop Bag	Professional 15-inch laptop bag made from genuine leather	36	2025-08-31 13:35:03.559815	2026-02-17 07:54:56.166928	3	8	11	11	{/uploads/products/19/1771314896167-laptop-bag.webp}
17	Wireless Bluetooth Headphones	Premium noise-canceling headphones with 30-hour battery life	90	2026-01-31 13:31:01.917631	2026-02-17 07:55:39.224957	3	14	15	11	{/uploads/products/17/1771314939225-wireless-bluetooth.webp}
7	Nike Air Zoom Pegasus 40	Responsive running shoes with enhanced cushioning for road running and daily training	130	2024-12-29 15:59:12.335631	2026-02-17 07:55:54.449921	3	8	17	11	{/uploads/products/7/1771314954450-nike-air.jpg}
15	Mcintyre and Stanton LLC	Veniam, ipsum, alias alias enim ea et iure dolores aperiam ex est omnis molestiae rerum maiores rerum ex consectetur facilis ut consequuntur veniam, a.	351	2024-12-29 19:55:55.777629	2026-02-17 07:56:34.152229	3	8	14	11	{/uploads/products/15/1771314994152-stainton.jpg}
6	Moroccan Mint Serenity	A refreshing blend of Chinese gunpowder green tea and organic peppermint leaves. This traditional North African favorite delivers a cooling, invigorating taste. Excellent served hot or iced.	16	2026-01-29 15:56:21.917691	2026-02-17 07:56:50.096763	3	9	17	11	{/uploads/products/6/1771315010097-morocan-mint.jpg}
3	Earl Grey Supreme	Earl Grey Supreme	18	2024-12-25 12:22:54.872288	2026-02-17 07:57:06.26311	3	9	16	11	{/uploads/products/3/1771315026263-early-grey.jpg}
4	Dragon Pearl Jasmine Green Tea	Handcrafted green tea pearls scented with fresh jasmine blossoms. Each pearl unfurls into delicate leaves releasing a sweet, floral aroma. Perfect for evening relaxation and meditation.	300	2026-01-25 12:30:48.654301	2026-02-17 07:57:21.890409	3	9	17	11	{/uploads/products/4/1771315041890-dragon-tea.jpg}
29	Professional Match Football Size 5	High-quality professional football designed for match and training use. Made from durable synthetic leather with reinforced stitching for excellent shape retention, control, and long-lasting performance. Suitable for natural grass and artificial turf.	2999	2026-02-19 13:55:54.955304	2026-02-19 13:55:54.955304	2	1	11	11	{/uploads/products/29/1771509354964-match-foot.jpg,/uploads/products/29/1771509354964-match-football.jpg}
\.


--
-- Data for Name: reviews; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reviews (id, text, rating, "createdAt", "updatedAt", user_id, product_id, store_id) FROM stdin;
3	a text to change review for me	3	2026-01-29 14:47:43.762779	2026-01-29 14:55:23.234604	11	4	3
2	some text for me	4	2026-01-29 14:47:24.01904	2026-01-29 15:33:13.464074	11	4	3
4	Хороший чай, но дороговато	4	2026-01-31 09:16:30.822063	2026-01-31 09:16:30.822063	5	4	3
5	Не понравился, слишком горький	2	2026-01-31 09:16:30.822063	2026-01-31 09:16:30.822063	7	3	3
6	Лучший чай, что я пробовал!	5	2026-01-31 09:16:30.822063	2026-01-31 09:16:30.822063	8	6	3
7	Отличный продукт, беру уже второй раз	5	2026-01-31 09:18:19.99419	2026-01-31 09:18:19.99419	5	4	3
8	Качество хорошее, но упаковка слабая	4	2026-01-31 09:18:19.99419	2026-01-31 09:18:19.99419	7	3	3
9	Ожидал большего за такую цену	3	2026-01-31 09:18:19.99419	2026-01-31 09:18:19.99419	8	6	3
10	Очень понравился, рекомендую	5	2026-01-31 09:18:19.99419	2026-01-31 09:18:19.99419	9	7	3
11	Нормально, без вау-эффекта	3	2026-01-31 09:18:19.99419	2026-01-31 09:18:19.99419	10	8	3
12	Совсем не понравился, больше не куплю	1	2026-01-31 09:18:19.99419	2026-01-31 09:18:19.99419	12	14	3
13	Хороший вариант на каждый день	4	2026-01-31 09:18:19.99419	2026-01-31 09:18:19.99419	13	15	3
14	Запах отличный, вкус средний	3	2026-01-31 09:18:19.99419	2026-01-31 09:18:19.99419	14	4	3
15	Цена завышена	2	2026-01-31 09:18:19.99419	2026-01-31 09:18:19.99419	15	3	3
16	Лучший в своей категории	5	2026-01-31 09:18:19.99419	2026-01-31 09:18:19.99419	16	6	3
17	Среднее качество, ожидал лучше	3	2026-01-31 09:18:19.99419	2026-01-31 09:18:19.99419	17	7	3
18	Очень доволен покупкой	5	2026-01-31 09:18:19.99419	2026-01-31 09:18:19.99419	11	8	3
19	Пришёл быстро, всё ок	4	2026-01-31 09:18:19.99419	2026-01-31 09:18:19.99419	6	14	3
20	Вкус странный, на любителя	2	2026-01-31 09:18:19.99419	2026-01-31 09:18:19.99419	5	15	3
21	Понравился всей семье	5	2026-01-31 09:18:19.99419	2026-01-31 09:18:19.99419	7	4	3
22	Беру не первый раз, стабильно хорошо	4	2026-01-31 09:18:19.99419	2026-01-31 09:18:19.99419	8	3	3
23	Качество упало по сравнению с прошлым разом	2	2026-01-31 09:18:19.99419	2026-01-31 09:18:19.99419	9	6	3
24	Просто отличный продукт	5	2026-01-31 09:18:19.99419	2026-01-31 09:18:19.99419	10	7	3
25	Ничего особенного	3	2026-01-31 09:18:19.99419	2026-01-31 09:18:19.99419	12	8	3
26	Разочарован покупкой	1	2026-01-31 09:18:19.99419	2026-01-31 09:18:19.99419	13	14	3
27	Хороший баланс цены и качества	4	2026-01-31 09:18:19.99419	2026-01-31 09:18:19.99419	14	15	3
28	Можно брать, но есть лучше	3	2026-01-31 09:18:19.99419	2026-01-31 09:18:19.99419	15	4	3
29	Очень вкусно, рекомендую	5	2026-01-31 09:18:19.99419	2026-01-31 09:18:19.99419	16	3	3
30	Слишком дорого для такого качества	2	2026-01-31 09:18:19.99419	2026-01-31 09:18:19.99419	17	6	3
31	Отличный аромат	4	2026-01-31 09:18:19.99419	2026-01-31 09:18:19.99419	11	7	3
32	Больше брать не буду	1	2026-01-31 09:18:19.99419	2026-01-31 09:18:19.99419	6	8	3
33	Приятно удивлён качеством	5	2026-01-31 09:18:19.99419	2026-01-31 09:18:19.99419	5	14	3
34	Обычный продукт, ничего особенного	3	2026-01-31 09:18:19.99419	2026-01-31 09:18:19.99419	7	15	3
35	Хороший, но быстро закончился	4	2026-01-31 09:18:19.99419	2026-01-31 09:18:19.99419	8	4	3
36	Мой любимый из этой линейки	5	2026-01-31 09:18:19.99419	2026-01-31 09:18:19.99419	9	3	3
\.


--
-- Data for Name: stores; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stores (id, title, description, "createdAt", "updatedAt", user_id, picture) FROM stdin;
3	My Store	Awesome store	2024-12-24 17:13:56.164353	2026-01-29 21:07:01.851401	11	/uploads/stores/3/1769720821837-bike-store.jpg
2	Sports wear	sport products	2026-01-24 16:31:13.082931	2026-02-04 05:25:53.571033	11	/uploads/stores/2/1770182753563-sport-shop.webp
\.


--
-- Data for Name: user_favorite_products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_favorite_products (user_id, product_id) FROM stdin;
11	19
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, "createdAt", "updatedAt", name, email, password, picture, role, cart_id) FROM stdin;
5	2026-01-24 07:41:47.682588	2026-01-24 07:41:47.682588	serii	serii@gmail.com	$argon2id$v=19$m=65536,t=3,p=4$EQ1f41IcukJoMyN9nZ5m+Q$HpZoFKrJbiTdHYcluVNIkKA7MM973FvFib+J2TtGcxI	/uploads/no-user-image.png	user	\N
7	2026-01-24 07:52:58.437063	2026-01-24 07:52:58.437063	No user name	givi@gmail.com	$argon2id$v=19$m=65536,t=3,p=4$K86TDSLPnungVyFzoJXoog$xvZ3w+pVNnf4TUU4IkVG8YjSKvErX4HBvHvsabPjS3A	/uploads/no-user-image.png	user	\N
8	2026-01-24 07:53:21.470485	2026-01-24 07:53:21.470485	No user name	johny@gmail.com	$argon2id$v=19$m=65536,t=3,p=4$01CvFgItQavk+rTCpUOG3A$hVyV7KTArz6Mb7CogSyIvih0X8mE2x5Spot4+WFTWA0	/uploads/no-user-image.png	user	\N
9	2026-01-24 07:54:05.623459	2026-01-24 07:54:05.623459	No user name	zezea@gmail.com	$argon2id$v=19$m=65536,t=3,p=4$Ji9n2aAXy1mSCWBh/ephnA$rWd1UojfpYEVQHuJPmygH1M96tu7AVB9TeiIR7Pe7eM	/uploads/no-user-image.png	user	\N
10	2026-01-24 08:07:46.429522	2026-01-24 08:07:46.429522	gosha	gosha@gmail.com	$argon2id$v=19$m=65536,t=3,p=4$JNBBWX0r5rEgBQPBwaBomA$so3fTMTruT4B3XWcL/RtS2RMKULS/UQIGl3s4ay/mKY	/uploads/no-user-image.png	user	\N
12	2026-01-24 10:01:02.623326	2026-01-24 10:01:02.623326	Bunny	bonnym@gmail.com	$argon2id$v=19$m=65536,t=3,p=4$LmcS66sIVLGTSqmxKGm5BA$eb1s0SyhJX5fe5cciBoOALZ9ZlwVRr05NSiK3xyy0fI	/uploads/no-user-image.png	user	\N
13	2026-01-24 10:02:42.686457	2026-01-24 10:02:42.686457	BunnyT	bonnytm@gmail.com	$argon2id$v=19$m=65536,t=3,p=4$5YhMLrVdr1dCmkE2ycYY5A$AmdsC0bkSw80MWmANQWnQIzqc2kJZN87VYF78DZAqfY	/uploads/no-user-image.png	user	\N
14	2026-01-24 10:03:56.269835	2026-01-24 10:03:56.269835	Test	test@mail.com	$argon2id$v=19$m=65536,t=3,p=4$9msHgaXfe4US8yZxtmhEvw$BtVuc2Q7x/xQHsH2DlTIXl2INyWji8SPg8dnEsI9cXc	/uploads/no-user-image.png	user	\N
15	2026-01-24 10:05:12.946835	2026-01-24 10:05:12.946835	Test	test2@mail.com	$argon2id$v=19$m=65536,t=3,p=4$EkfOwLbsQc5eQE95wQs/qA$JO2qtYw1+3s9maXR45Pi896cTfVHIHP259bhwRo2dx8	/uploads/no-user-image.png	user	\N
16	2026-01-24 10:08:25.855561	2026-01-24 10:08:25.855561	Test	test3@mail.com	$argon2id$v=19$m=65536,t=3,p=4$3e50INjfehA4lDIFtXkGew$/Uf/02jmvxrAVxtZN7diGsXOMlcpdFeQLYU40XTzdAM	/uploads/no-user-image.png	user	\N
17	2026-01-24 17:14:49.785017	2026-01-24 17:14:49.785017	Test	test4@mail.com	$argon2id$v=19$m=65536,t=3,p=4$MueMeMFzQ2pVct5BEKYSsw$rB+cwiistadCongN8R5Kg5UYusALsDbL6e5LokNAhTg	/uploads/no-user-image.png	user	\N
6	2026-01-24 07:52:21.57201	2026-01-24 07:52:21.57201	No user name	nixon@gmail.com	$argon2id$v=19$m=65536,t=3,p=4$IlxGDQdifAHj6A1ayURkFw$YPYonYmZIs5kflq3ZodfegDttw6nh8QSZoWnqMv2cqA	/uploads/no-user.webp	user	\N
11	2026-01-24 09:53:56.869527	2026-02-19 20:47:36.114208	Serii	seriiburduja@gmail.com	$argon2id$v=19$m=65536,t=3,p=4$GOZOQ9HBiLbypXkDiJB5Cg$xlBRdfw1l1diA5PdTbrSenBgyUNFkNk2Js0e1OLuZag	/uploads/no-user.webp	admin	1
\.


--
-- Name: cart_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cart_items_id_seq', 8, true);


--
-- Name: carts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.carts_id_seq', 1, true);


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.categories_id_seq', 14, true);


--
-- Name: colors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.colors_id_seq', 17, true);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.migrations_id_seq', 26, true);


--
-- Name: order_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_items_id_seq', 4, true);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.orders_id_seq', 5, true);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.products_id_seq', 29, true);


--
-- Name: reviews_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reviews_id_seq', 36, true);


--
-- Name: stores_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.stores_id_seq', 4, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 17, true);


--
-- Name: order_items PK_005269d8574e6fac0493715c308; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT "PK_005269d8574e6fac0493715c308" PRIMARY KEY (id);


--
-- Name: products PK_0806c755e0aca124e67c0cf6d7d; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT "PK_0806c755e0aca124e67c0cf6d7d" PRIMARY KEY (id);


--
-- Name: reviews PK_231ae565c273ee700b283f15c1d; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT "PK_231ae565c273ee700b283f15c1d" PRIMARY KEY (id);


--
-- Name: categories PK_24dbc6126a28ff948da33e97d3b; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT "PK_24dbc6126a28ff948da33e97d3b" PRIMARY KEY (id);


--
-- Name: colors PK_3a62edc12d29307872ab1777ced; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.colors
    ADD CONSTRAINT "PK_3a62edc12d29307872ab1777ced" PRIMARY KEY (id);


--
-- Name: user_favorite_products PK_6b38b391113aa0ca9360f470da3; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_favorite_products
    ADD CONSTRAINT "PK_6b38b391113aa0ca9360f470da3" PRIMARY KEY (user_id, product_id);


--
-- Name: cart_items PK_6fccf5ec03c172d27a28a82928b; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT "PK_6fccf5ec03c172d27a28a82928b" PRIMARY KEY (id);


--
-- Name: orders PK_710e2d4957aa5878dfe94e4ac2f; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "PK_710e2d4957aa5878dfe94e4ac2f" PRIMARY KEY (id);


--
-- Name: stores PK_7aa6e7d71fa7acdd7ca43d7c9cb; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stores
    ADD CONSTRAINT "PK_7aa6e7d71fa7acdd7ca43d7c9cb" PRIMARY KEY (id);


--
-- Name: migrations PK_8c82d7f526340ab734260ea46be; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT "PK_8c82d7f526340ab734260ea46be" PRIMARY KEY (id);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: carts PK_b5f695a59f5ebb50af3c8160816; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carts
    ADD CONSTRAINT "PK_b5f695a59f5ebb50af3c8160816" PRIMARY KEY (id);


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: users UQ_cbfb19ddc0218b26522f9fea2eb; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_cbfb19ddc0218b26522f9fea2eb" UNIQUE (cart_id);


--
-- Name: IDX_3f5c6496edcc249b5edcb54add; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_3f5c6496edcc249b5edcb54add" ON public.user_favorite_products USING btree (user_id);


--
-- Name: IDX_ce71c9d4ce234802e27f909c64; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_ce71c9d4ce234802e27f909c64" ON public.user_favorite_products USING btree (product_id);


--
-- Name: colors FK_006d8c2737c2560799a0de12f0d; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.colors
    ADD CONSTRAINT "FK_006d8c2737c2560799a0de12f0d" FOREIGN KEY (store_id) REFERENCES public.stores(id) ON DELETE CASCADE;


--
-- Name: order_items FK_145532db85752b29c57d2b7b1f1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT "FK_145532db85752b29c57d2b7b1f1" FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: products FK_176b502c5ebd6e72cafbd9d6f70; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT "FK_176b502c5ebd6e72cafbd9d6f70" FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: stores FK_29f39971656b4bf7832b7476d10; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stores
    ADD CONSTRAINT "FK_29f39971656b4bf7832b7476d10" FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: cart_items FK_30e89257a105eab7648a35c7fce; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT "FK_30e89257a105eab7648a35c7fce" FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: user_favorite_products FK_3f5c6496edcc249b5edcb54add7; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_favorite_products
    ADD CONSTRAINT "FK_3f5c6496edcc249b5edcb54add7" FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: reviews FK_53d569324f429e5d3af161f1657; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT "FK_53d569324f429e5d3af161f1657" FOREIGN KEY (store_id) REFERENCES public.stores(id) ON DELETE CASCADE;


--
-- Name: categories FK_5848ba82e61b83e2aa416447a15; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT "FK_5848ba82e61b83e2aa416447a15" FOREIGN KEY (store_id) REFERENCES public.stores(id) ON DELETE CASCADE;


--
-- Name: cart_items FK_6385a745d9e12a89b859bb25623; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT "FK_6385a745d9e12a89b859bb25623" FOREIGN KEY (cart_id) REFERENCES public.carts(id) ON DELETE CASCADE;


--
-- Name: products FK_68863607048a1abd43772b314ef; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT "FK_68863607048a1abd43772b314ef" FOREIGN KEY (store_id) REFERENCES public.stores(id) ON DELETE CASCADE;


--
-- Name: reviews FK_728447781a30bc3fcfe5c2f1cdf; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT "FK_728447781a30bc3fcfe5c2f1cdf" FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: products FK_733888c65449d717af1fccaf702; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT "FK_733888c65449d717af1fccaf702" FOREIGN KEY (color_id) REFERENCES public.colors(id) ON DELETE SET NULL;


--
-- Name: order_items FK_9263386c35b6b242540f9493b00; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT "FK_9263386c35b6b242540f9493b00" FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: reviews FK_9482e9567d8dcc2bc615981ef44; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT "FK_9482e9567d8dcc2bc615981ef44" FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: products FK_9a5f6868c96e0069e699f33e124; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT "FK_9a5f6868c96e0069e699f33e124" FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE SET NULL;


--
-- Name: orders FK_a922b820eeef29ac1c6800e826a; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "FK_a922b820eeef29ac1c6800e826a" FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: orders FK_b7a7bb813431fc7cd73cced0001; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "FK_b7a7bb813431fc7cd73cced0001" FOREIGN KEY (store_id) REFERENCES public.stores(id);


--
-- Name: users FK_cbfb19ddc0218b26522f9fea2eb; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "FK_cbfb19ddc0218b26522f9fea2eb" FOREIGN KEY (cart_id) REFERENCES public.carts(id);


--
-- Name: user_favorite_products FK_ce71c9d4ce234802e27f909c64a; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_favorite_products
    ADD CONSTRAINT "FK_ce71c9d4ce234802e27f909c64a" FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: order_items FK_fb643226ed89f5074870af43d72; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT "FK_fb643226ed89f5074870af43d72" FOREIGN KEY (store_id) REFERENCES public.stores(id);


--
-- PostgreSQL database dump complete
--

\unrestrict 1m0H8x7SuozH5YFog2l5gcYtAmK9fAai8MsL2DBTZMhAWxruN9nxhUfNiT7e3fK

